const BaseController = require('../core/BaseController');

class Policy extends BaseController {
    constructor(_req, _res) {
        super(_req, _res);
    }

    print() 
    {
        this.view.render("policy", {});
    }
}

module.exports = Policy;
