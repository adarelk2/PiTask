const BaseController = require('../core/BaseController');

class Terms extends BaseController {
    constructor(_req, _res) {
        super(_req, _res);
    }

    print() 
    {
        this.view.render("terms", {});
    }
}

module.exports = Terms;
