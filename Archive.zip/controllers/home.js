const Controller = require("../core/Controller");

class Home extends Controller 
{
    constructor(_req, _res)
    {
        super(_req, _res)
    }

    print()
    {
        this.res.render('home', {
            title: 'TaskPi',
            headerData: { username: 'adar' },
            contentData: { text: 'Welcome to your dashboard' },
            footerData: { year: new Date().getFullYear() }
          });    
    }

  }
  
  module.exports = Home;
  