const fs = require('fs');
const path = require('path');

class Controller {
    constructor(_req, _res) 
    {
        this.req = _req;
        this.res = _res;
        this.errors = [];
        this.model;
        this.view;
        return this;
    }
  
    getControllersFiles = ()=>
    {
        const controllersPath = path.join(__dirname, '../controllers');
        const files = fs.readdirSync(controllersPath);
        return files;
    }

    isControllerExist = (_controller)=>
    {
        return this.getControllersFiles().includes(_controller + ".js")
    }

    isMethodExist = (_controller, _method)=>
    {
        const isControllerExist = this.isControllerExist(_controller);
        if(isControllerExist)
        {
            const ClassRef = require("../controllers/" + _controller);
            const instance = new ClassRef();
          
            const prototype = Object.getPrototypeOf(instance);
            const methodNames = Object.getOwnPropertyNames(prototype)
              .filter(name => name !== 'constructor' && typeof instance[name] === 'function');
            return methodNames.indexOf(_method) >=0;
        }

        return false;
    }

    getController = (_controller)=>
    {
        const isControllerExist = this.isControllerExist(_controller);
        if(isControllerExist)
        {
            const ClassRef = require("../controllers/" + _controller);
            return new ClassRef(this.req, this.res);
        }
    }
}
  
  module.exports = Controller;
  