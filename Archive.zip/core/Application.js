const path = require('path');
const Controller = require('./Controller');

class Application {
  constructor(req, res) {
    this.req = req;
    this.res = res;
    this.controllerName = req.params.controller || 'Home'; // default to Home
    this.methodName = req.query.method || 'print';         // default to print
    this.params = req.query.params || {};
    this.controllerHelper = new Controller(req, res); // helper to load + validate
    this.errors = [];
  }

  init() {
    if (!this.isValidRequest()) {
      return this.res.render('error', { errors: this.errors });
    }

    const controllerInstance = this.controllerHelper.getController(this.controllerName);
    controllerInstance[this.methodName](this.params); // optional: pass params
  }

  isValidRequest() {
    const isControllerExist = this.controllerHelper.isControllerExist(this.controllerName);
    if (!isControllerExist) {
      this.errors.push("Error 404 – Controller not found.");
      return false;
    }

    const isMethodExist = this.controllerHelper.isMethodExist(this.controllerName, this.methodName);
    if (!isMethodExist) {
      this.errors.push(`Error 999 – Method '${this.methodName}' not found in '${this.controllerName}'`);
      return false;
    }

    return true;
  }
}

module.exports = Application;
